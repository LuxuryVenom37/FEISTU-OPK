# CMake generated Testfile for 
# Source directory: /media/viktor/Data/OPK/CV3/cmake-build-debug/_deps/googletest-src/googlemock
# Build directory: /media/viktor/Data/OPK/CV3/cmake-build-debug/_deps/googletest-build/googlemock
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
subdirs("../googletest")
